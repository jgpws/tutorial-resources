<?php ?>
  <p><?php esc_html_e( 'Mixin\' Styles- GB uses full site editing, requiring the Gutenberg plugin to be installed and activated.', 'mixin-styles-gb' ); ?></p>
