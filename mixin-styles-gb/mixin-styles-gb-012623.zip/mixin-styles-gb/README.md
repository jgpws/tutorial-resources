# Mixin' Styles- GB

Mixin' Styles- GB is a full site editing blog theme. Sporting rounded corners on several elements, Mixin' Styles- GB supports single columns and sidebar layouts via a collection of templates and patterns. Custom templates include a page with a left-side fixed vertical header, a page with no sidebar and a no sidebar pattern for posts. The theme offers four header styles including two with hero images.

A theme homepage and documentation will be coming soon.
