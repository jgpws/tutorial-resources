# Mixin' Styles- GB

* [Mixin' Styles- GB Homepage](https://www.jasong-designs.com/2022/05/25/mixin-styles-gb/)

Mixin' Styles- GB is a full site editing blog theme.

Sporting rounded corners on several elements, Mixin' Styles- GB supports single columns and sidebar layouts via a collection of templates and patterns.

Custom templates include a page with a left-side fixed vertical header, a page with no sidebar and a no sidebar pattern for posts.

The theme offers four header styles including two with hero images.

## Installation Instructions

* Click the **Clone or download** button, then from the dropdown, **Download ZIP**
* This will likely download to a Downloads or My Downloads folder on your computer
* Login to WordPress
* In the WordPress dashboard, click **Themes** under the **Appearance** menu item
* Click **Add New**
* Then click **Upload theme**
* Click the **Browse** button and navigate to where the zip file is (Downloads folder). Browse may be named something else depending on your operating system
* Click **Install Now**
